package com.loc.newsapp.presentation.video

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

data class Video(val title: String, val url: String)

data class VideoScreenState(val videos: List<Video> = emptyList())

class VideoViewModel : ViewModel() {
    private val _state = MutableLiveData(VideoScreenState())
    val state: LiveData<VideoScreenState> get() = _state

    init {
        _state.value = VideoScreenState(
            videos = listOf(
                Video("Sample Video 1", "https://www.youtube.com/watch?v=Yy9La6YXNqI"),
                Video("Sample Video 2", "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
            )
        )
    }
}

