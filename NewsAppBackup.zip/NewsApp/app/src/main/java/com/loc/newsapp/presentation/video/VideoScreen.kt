package com.loc.newsapp.presentation.video

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun VideoScreen(
    viewModel: VideoViewModel = viewModel(),
    navController: NavController
) {
    // Correctly observing LiveData with 'observeAsState' and providing an initial value
    val state by viewModel.state.observeAsState(initial = VideoScreenState())

    Scaffold(
        topBar = { TopAppBar(title = { Text("Video List") }) }
    ) { paddingValues ->
        VideoList(videos = state.videos, navigateToVideoDetails = { video ->
            navigateToVideoDetails(navController, video)
        })
    }
}

fun navigateToVideoDetails(navController: NavController, video: Video) {
    val encodedVideoUrl = URLEncoder.encode(video.url, "UTF-8")
    navController.navigate("videoDetails/$encodedVideoUrl")
}

@Composable
fun VideoList(videos: List<Video>, navigateToVideoDetails: (Video) -> Unit) {
    LazyColumn {
        items(videos) { video ->
            VideoItem(video = video, navigateToVideoDetails = { navigateToVideoDetails(video) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoItem(video: Video, navigateToVideoDetails: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        onClick = navigateToVideoDetails
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = video.title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(text = "Click to view details", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MaterialTheme {
        // Since navigateToVideoDetails requires a function that takes a Video,
        // we'll pass an empty lambda for the preview since it's not actionable.
        VideoList(
            videos = listOf(
                Video("Sample Video 1", "https://www.youtube.com/watch?v=Yy9La6YXNqI"),
                Video("Sample Video 2", "https://www.youtube.com/watch?v=dQw4w9WgXcQ")
            ),
            navigateToVideoDetails = {}
        )
    }
}
