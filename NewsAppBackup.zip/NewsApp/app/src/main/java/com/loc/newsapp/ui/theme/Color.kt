package com.loc.newsapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Black = Color(0xFF1C1E21)
val Blue = Color(0xFF1877F2)

val DarkRed = Color(0xFFC30052) //Dark Error
val LightRed = Color(0xFFFF84B7)

val LightBlack = Color(0xFF3A3B3C)
val Nevada = Color(0xFFC0A16C)
val NightStalker = Color(0xFF14293F)
val OldWordBlue = Color(0xFF1D3A58)
val VATS = Color(0xFF3A8529)

val BlueGray = Color(0xFFA0A3BD)
val WhiteGray = Color(0xFFB0B3B8)

val cardColor: Color
    @Composable
    get() {
        return if (isSystemInDarkTheme()) OldWordBlue
        else Color.White
    }