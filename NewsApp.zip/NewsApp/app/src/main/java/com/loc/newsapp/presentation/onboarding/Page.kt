package com.loc.newsapp.presentation.onboarding

import androidx.annotation.DrawableRes
import com.loc.newsapp.R

data class Page(
    val  title:String,
    val description:String,
    @DrawableRes val image: Int
)

val pages = listOf(
    Page(
        title = "Skyrim",
        description ="The game that Todd Howard can't let go...",
        image = R.drawable.onboarding1

    ),
    Page(
        title = "Darkest Dungeon",
        description ="Being an adventurer, isn't easy",
        image = R.drawable.onboarding2

    ),
    Page(
        title = "Team Fortress 2",
        description ="Valve please update the game",
        image = R.drawable.onboarding3

    )
)