package com.loc.newsapp.util

object Constants {
    const val USER_SETTINGS="userSettings"

    const val APP_ENTRY ="appEntry"

    const val API_KEY="3b44789542e44e1d8f30eaa80f630002"

    const val BASE_URL ="https://newsapi.org/"

    const val NEWS_DATABASE_NAME="news_db"

}